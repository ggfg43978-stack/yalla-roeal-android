# تطبيق Yalla Roeal لأندرويد

تطبيق Android خاص يفتح الموقع `https://yalaroeal.com` داخل WebView ويدعم تسجيل الدخول، رفع الصور والفيديو، الكاميرا والميكروفون، الموقع، التنزيل، الروابط الخارجية وزر الرجوع.

## إنشاء APK

1. افتح المجلد في Android Studio.
2. انتظر اكتمال Gradle Sync.
3. اختر **Build > Build APK(s)**.
4. ستجد النسخة التجريبية في `app/build/outputs/apk/debug/app-debug.apk`.

لإنشاء نسخة موقعة قابلة للتحديث لاحقًا اختر **Build > Generate Signed App Bundle or APK** ثم احتفظ بملف مفتاح التوقيع في مكان آمن.

## البناء من الهاتف عبر GitHub

المشروع يحتوي على بناء سحابي جاهز. بعد رفعه إلى مستودع GitHub افتح تبويب **Actions**، واختر **Build Yalla Roeal APK** ثم اضغط **Run workflow**. بعد اكتمال البناء نزّل **Yalla-Roeal-APK** من قسم Artifacts.
